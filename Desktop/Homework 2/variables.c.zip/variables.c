#include <stdio.h>
int main() {
// puts("1*1=1");
// puts("1*2=2");
// puts("1*3=3");
// puts("1*4=4");
// puts("1*5=5");
// puts("1*6=6");
// puts("1*7=7");
// puts("1*8=8");
// puts("1*9=9");
// puts("1*10=10");

// puts("2*1=2");
// puts("2*2=4");
// puts("2*3=6");
// puts("2*4=8");
// puts("2*5=10");
// puts("2*6=12");
// puts("2*7=14");
// puts("2*8=16");
// puts("2*9=18");
// puts("2*10=20");

// puts("3*1=3");
// puts("3*2=6");
// puts("3*3=9");
// puts("3*4=12");
// puts("3*5=15");
// puts("3*6=18");
// puts("3*7=21");
// puts("3*8=24");
// puts("3*9=27");
// puts("3*10=30");


// int a=4, b=5, c=3, d=5, e=5, orta_baho;
// orta_baho=(a+b+c+d+e)/5;
// printf("(%d+%d+%d+%d+%d)/5=%d",a,b,c,d,e, (a+b+c+d+e)/5);

// int a=2, b=5, c=3, abc=253, natija;
// natija=a+10*b+100*c;
// printf("%d+%d+%d=%d", a, 10*b, 100*c, a+10*b+100*c);

// int a=4, b=5, number=b+10*a, natija;
// scanf("%d", &number);
// printf("kiritilgan son -> %d", number);
// printf("Natija-> %d+%d=%d", a, 10*b, a+10*b);

// puts("*/t/t*");
// puts("/t*/t*");
// puts("/t/t*");
// puts("/t*/t*");
// puts("*/t/t*");

}