int main() {
    // int a=2, b=3, c=4, natija;
    // a=natija/100;
    // b=(natija/10)%10;
    // c=natija%10;
    // natija=c+10*b+100*2;

// int A=25, x, y, B;
// y=A%10;
// x=A/10;
// B=x+10*y;

// int SON=125, birlar, yuzlar;
// birlar=SON%10;
// yuzlar=SON/100;





}