# include <stdio.h>


// void Butun(int son ){
//     printf("Outpu: %d",son );
// }



// int main(){
//     float n;
//     printf("Kiriting: ");
//     scanf("%f", &n);
//     Butun(n);

// }








// void Teskari(int *n){
//     for(; *n; *n=*n/10){
//         int raqamlari=*n%10;
//         printf("%d",raqamlari);
//     }
// }


// int main(){
//     int n;
//     printf("Sonni kiriting: ");
//     scanf("%d", &n);
//     Teskari(&n);
    

// }







// void ScanArr(int *a, int uzunlik){
//     for(int i=0; i<uzunlik; i++){
//         scanf("%d", &a[i]);
//     }
// }

// void change(int *a, int uzunlik ){
//     for(int i=0; i<uzunlik; i++){
//        if((*(a+i))%2==0) printf("%d ",2* (*(a+i)));
//        else printf("%d ", *(a+i)-5);
//     }
// }




// int main(){
//     int n;
//     printf("Nechta son kiritasiz: ");
//     scanf("%d", &n);
//     int arr[n];
//     ScanArr(arr, n);
//     change(arr, n);
// }
