#include <stdio.h>
int main(){
    // int n, a=1, hisobla_juft=0, hisobla_toq=0;
    // printf("Stopni kiriting: ");
    // scanf("%d", &n);

    // while(n>=a){
    //     if(a%2==0){
    //         hisobla_juft=hisobla_juft+a;
    //         a+=1;
    //     }else{
    //         hisobla_toq=hisobla_toq+a;
    //         a+=1;
    //     }
    // }printf("Juft: %d\n", hisobla_juft);
    // printf("Toq: %d\n", hisobla_toq);




    //  int n, a=1, hisobla_juft=0, hisobla_toq=0;
    // printf("Stopni kiriting: ");
    // scanf("%d", &n);

    // while(n>=a){
    //     if(a%2==0){
    //         hisobla_juft=hisobla_juft+a;
    //         a+=1;
    //     }else{
    //         hisobla_toq=hisobla_toq+a;
    //         a+=1;
    //     }
    // }if(hisobla_juft>hisobla_toq){
    //     printf("Eng kattasi: Juft-> %d", hisobla_juft);
    // }else if(hisobla_toq>hisobla_juft){
    //     printf("Eng kattasi: Toq-> %d", hisobla_toq);
    // }else{
    //     printf("NAtija teng");
    // }




    // int son, raqami_1;
    // printf("Sonni kiritng: ");
    // scanf("%d", &son);
    
    // while(son>=10){
    //     son=son/10;
    // }raqami_1=son;
    // printf("%d", raqami_1);



    // int son, hisobla=0;
    // printf("Sonni kiriting: ");
    // scanf("%d", &son);

    // while(son!=0){
    //     hisobla=hisobla+son%10;
    //     son/=10;
    // }printf("Raqamlar yig'indisi: %d", hisobla);



    // int son, a=0;//a->Raqamlar nechtaligini sanovchi
    // printf("Sonni kiriting: ");
    // scanf("%d", &son);

    // while(son!=0){
    //     a=a+1;
    //     son/=10;
    // }printf("Raqamlar soni: %d", a);
















    







    
    }










