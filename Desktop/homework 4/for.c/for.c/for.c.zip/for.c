#include <stdio.h>
int main(){
  //   int son, yigindi=0, fakt=1;
  //   printf("Sonni kiriting: ");
  //   scanf("%d", &son);

  //   for(int i=son,  raqamlari=0; i!=0; i=i/10 ){
  //       raqamlari=i%10;

  //       for(int j=1; j<=raqamlari; j++ ){
  //         fakt=j*fakt;
  //       }
  //       yigindi=yigindi+fakt;
  //       fakt=1;
 
  // }
  // yigindi==son ? printf("Strong Number") : printf("Oddiy son");
  










//   int son, hisoblovchi=1, xonalar=0, natija=0;
//   printf("Sonni kiriting: ");
//   scanf("%d", &son);
  
//  if(son!=0)
//   for(int i=son, raqamlari=0 ; i!=0; i/=10 ){
//     raqamlari=i%10;
//     xonalar+=1;
//   }else xonalar=1;
//   for(int j=son, raqam=0 ; j!=0; j/=10 ){
//     raqam=j%10;
  
//     for(int j=1; j<=xonalar; j++){

//        hisoblovchi=raqam*hisoblovchi;

//     }natija=natija+hisoblovchi;
//     hisoblovchi=1;
//  }

//  natija==son ? printf("Armstrong Number") : printf("Oddiy son");










}