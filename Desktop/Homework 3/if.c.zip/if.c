#include <stdio.h>
int main(){
    // int a,b;
    // printf("1-sonni kiriting: ");
    // scanf("%d", &a);
    // printf("2-sonni kiriting: ");
    // scanf("%d", &b);

    // if((a%2==0&&b%2==1)||(a%2==1&&b%2==0)){
    //     printf("True");
    // }else{
    //     printf("False");
    // }
    
//    int a,b;
// printf("1-sonni kiriting: ");
// scanf("%d", &a);
//     printf("2-sonni kiriting: ");
//     scanf("%d", &b);

//     if (a%3==0&&b%3==0){
//         printf("True");
//     }else{
//         printf("False");
//     }






// int a, b,c, d;
//  printf("1-sonni kiriting: ");
//  scanf("%d", &a);
//  printf("2-sonni kiriting: ");
//  scanf("%d", &b);
//  printf("3-sonni kiriting: ");
//  scanf("%d", &c);
//  printf("4-sonni kiriting: ");
//  scanf("%d", &d);

//  if((a%2==0&&b%2==0)||(c%2==0&&d%2==0)){
//     printf("%d, %d, %d, %d", a, b, c, d);

// }else if((a%2==0&&c%2==0)||(b%2==0&&d%2==0)){
//     printf("%d, %d, %d, %d", a, b, c, d);
// }else if ((a%2==0&&d%2==0)||(b%2==0&&c%2==0)){
//     printf("%d, %d, %d, %d", a, b, c, d);
// }else{
//     puts("0");
// }







// int a, b, c, d, e, orta_hisob;
//  printf("1-sonni kiriting: ");
//  scanf("%d", &a);
//  printf("2-sonni kiriting: ");
//  scanf("%d", &b);
//  printf("3-sonni kiriting: ");
//  scanf("%d", &c);
//  printf("4-sonni kiriting: ");
//  scanf("%d", &d);
//  printf("5-sonni kiriting: ");
//  scanf("%d", &e);

// orta_hisob=(a+b+c+d+e)/5;

// if(orta_hisob==5){
//     printf("A'lochi");
// }else if (orta_hisob==4)
// {printf("Yaxshi");
// }else if(orta_hisob==3){
//     printf("Qoniqarli");
// }

 





// int a;
// printf("sonni kiriting: ");
// scanf("%d", &a);

// if(a==1){
//     printf("bir");
// }else if(a==2){
//     printf("ikki");
// }else if(a==3){
//     printf("uch");
// }else if(a==4){
//     printf("to'rt");
// }else if(a==5){
//     printf("besh");
// }else if(a==6){
//     printf("olti");
// }else if(a==7){
//     printf("yetti");
// }else if(a==8){
//     printf("sakkiz");
// }else if(a==9){
//     printf("to'qqiz");
// }else if(a==10){
//     printf("o'n");
// }else if(a==11){
//     printf("o'n bir");
// }else if(a==12){
//     printf("o'n ikki");
// }else if(a==13){
//     printf("o'n uch");
// }else if(a==14){
//     printf("o'n to'rt");
// }else if(a==15){
//     printf("o'n besh");
// }else if(a==16){
//     printf("o'n olti");
// }else if(a==17){
//     printf("o'n yetti");
// }else if(a==18){
//     printf("o'n sakkiz");
// }else if(a==19){
//     printf("o'n to'qqiz");
// }else if(a==20){
//     printf("yigirma");
// }else if(a==30){
//     printf("o'ttiz");
// }else if(a==40){
//     printf("qirq");
// }else if(a==50){
//     printf("ellik");
// }else if(a==70){
//     printf("yetmish");
// }else if(a==80){
//     printf("sakson");
// }else if(a==90){
//     printf("to'qson");
// }else{
//     printf("Sonlar oralig'i 10 dan 99 gacha");
// }






// int a;
// printf("Son kiriting: ");
// scanf("%d", &a);

// if(a%3==0&&a%5==0){
//     printf("FizzBuzz");}
// else if(a%3==0&&a%5!=0){
//     printf("Fizz");}

// else if(a%5==0&&a%3!=0){
//     printf("Buzz");

// }
// else {
//     printf("noto'g'ri son");
// }









// int input, a, A;
// printf("Kiriting: ");
// scanf("%d%d", &a, &A);

// if(input==a){
//     printf("%d", A);
// }else if(input==A){
//     printf("%d", a);
// }else{
//     printf("Xatolik");
// }

//4 va 6 savollar











}